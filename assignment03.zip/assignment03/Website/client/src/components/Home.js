import React from 'react'

const Home = () => {
  return (
    <div className='container mt-4 text-center'>
      <h3>GuruKul</h3>
      <img src="https://bucket-thesocialtalks.s3.amazonaws.com/static/article/2021/12/11/Screenshot_20211211-013554_Google_cdLYp9C.jpg" className='img img-fluid mt-2' style={{height: '500px'}} alt="" />
    </div>
  )
}

export default Home